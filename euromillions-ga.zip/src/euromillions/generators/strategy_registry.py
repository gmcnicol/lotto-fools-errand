# src/euromillions/generators/strategy_registry.py

from euromillions.generators import strategy_example

STRATEGY_REGISTRY = {
    "strategy_example": strategy_example.generate_strategy_example,
}

def get_strategy_function(name: str):
    if name not in STRATEGY_REGISTRY:
        raise ValueError(f"Unknown strategy: {name}")
    return STRATEGY_REGISTRY[name]
