# src/euromillions/generators/strategy_example.py

import random
import pandas as pd
from typing import List, Tuple

def generate_strategy_example(draws_df: pd.DataFrame, step: int = 1, window: int = 100) -> List[Tuple[List[int], List[int]]]:
    """
    Example strategy: Use simple increment pattern on recent draws.
    """
    recent_draws = draws_df.sort_values("date", ascending=False).head(window)
    base_draw = recent_draws.iloc[::step]

    tickets = []
    for _, draw in base_draw.iterrows():
        base_main = draw["main_numbers"]
        base_stars = draw["lucky_stars"]

        # Rotate numbers for demonstration
        ticket_main = [(n + 1 if n < 50 else 1) for n in base_main][:5]
        ticket_stars = [(s + 1 if s < 12 else 1) for s in base_stars][:2]

        tickets.append((sorted(ticket_main), sorted(ticket_stars)))
        if len(tickets) == 10:
            break

    return tickets
