import pandas as pd
from typing import Callable, List
from euromillions.generators.ticket_generator import get_strategy_function
from euromillions.euromillions_loader import load_draws, load_prizes

TICKET_COST = 2.50  # EuroMillions cost per line

def calculate_prize(main_matches: int, star_matches: int, draw_id: int, prizes_df: pd.DataFrame) -> float:
    """
    Look up actual prize for this combination of matches for a draw.
    """
    prize_row = prizes_df[
        (prizes_df.draw_id == draw_id) &
        (prizes_df.matched_numbers == main_matches) &
        (prizes_df.matched_stars == star_matches)
        ]
    if prize_row.empty:
        return 0.0
    return prize_row.iloc[0].prize or 0.0


def match_ticket_to_draw(ticket: tuple, draw_row: pd.Series) -> tuple:
    """
    Compare ticket to draw result and return match counts.
    """
    ticket_main, ticket_stars = set(ticket[0]), set(ticket[1])
    draw_main, draw_stars = set(draw_row.main_numbers), set(draw_row.star_numbers)
    return len(ticket_main & draw_main), len(ticket_stars & draw_stars)


def evaluate_genome(
        genome: List[int],
        strategy_names: List[str],
        draws_df: pd.DataFrame,
        prizes_df: pd.DataFrame,
        step: int = 3,
        window: int = 100,
) -> float:
    """
    Evaluate a genome of strategies over the full history.
    Returns cumulative P&L (profit and loss).
    """
    selected_strategies = [name for bit, name in zip(genome, strategy_names) if bit]
    if not selected_strategies:
        return -9999  # Punish empty genomes

    total_pnl = 0.0
    # Start from 1 to always predict draw[i] using draw[:i]
    for i in range(1, len(draws_df)):
        history = draws_df.iloc[:i]
        actual_draw = draws_df.iloc[i]
        draw_id = actual_draw.draw_id

        # Combine all selected strategies’ tickets
        tickets = []
        for strategy in selected_strategies:
            func = get_strategy_function(strategy)
            generated = func(history, step=step, window=window)
            tickets.extend(generated)

        # Only evaluate up to 10 lines
        tickets = tickets[:10]
        pnl = -len(tickets) * TICKET_COST

        for ticket in tickets:
            main_matches, star_matches = match_ticket_to_draw(ticket, actual_draw)
            pnl += calculate_prize(main_matches, star_matches, draw_id, prizes_df)

        total_pnl += pnl

    return round(total_pnl, 2)
